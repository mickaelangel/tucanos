pub fn acot<T>(x: T) -> T {
    unimplemented!()
}

pub fn acoth<T>(x: T) -> T {
    unimplemented!()
}

pub fn acsc<T>(x: T) -> T {
    unimplemented!()
}

pub fn acsch<T>(x: T) -> T {
    unimplemented!()
}

pub fn asec<T>(x: T) -> T {
    unimplemented!()
}

pub fn asech<T>(x: T) -> T {
    unimplemented!()
}

pub fn cot<T>(angle: T) -> T {
    unimplemented!()
}

pub fn coth<T>(angle: T) -> T {
    unimplemented!()
}

pub fn csc<T>(angle: T) -> T {
    unimplemented!()
}

pub fn csch<T>(angle: T) -> T {
    unimplemented!()
}

pub fn sec<T>(angle: T) -> T {
    unimplemented!()
}

pub fn sech<T>(angle: T) -> T {
    unimplemented!()
}
