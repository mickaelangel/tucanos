use na::{Scalar, U2};

use crate::aliases::TVec;

pub fn float_distance<T>(x: T, y: T) -> u64 {
    unimplemented!()
}

pub fn float_distance2<T: Scalar>(x: &TVec2<T>, y: &TVec2<T>) -> TVec<u64, U2> {
    unimplemented!()
}

pub fn next_float<T>(x: T) -> T {
    unimplemented!()
}

pub fn next_float2<T>(x: T, Distance: u64) -> T {
    unimplemented!()
}

pub fn prev_float<T>(x: T) -> T {
    unimplemented!()
}

pub fn prev_float2<T>(x: T, Distance: u64) -> T {
    unimplemented!()
}
