//use na::Scalar;
//
//
//use crate::aliases::TVec;

//pub fn iround<T: Scalar, const D: usize>(x: &TVec<T, D>) -> TVec<i32, D> {
//    x.map(|x| x.round())
//}
//
//pub fn log2<I>(x: I) -> I {
//    unimplemented!()
//}
//
//pub fn uround<T: Scalar, const D: usize>(x: &TVec<T, D>) -> TVec<u32, D>  {
//    unimplemented!()
//}
